history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
apt update
apt clean
apt update
cat sources.list
cat /etc/sources.list
cat /etc/apt/sources.list
cat /etc/resolve.conf
cat /etc/resolv.cong
cat /etc/resolv.conf
nano /etc/resolv.conf
vim /etc/resolv.conf
vim /etc/resolv.conf
apt update
ping -c 8.8.8.8
ping -c 4 8.8.8.8
cat /etc/resolv.conf
vim /etc/resolv.conf
cat /etc/resolv.conf
apt update
cat /etc/resolv.conf
cat /etc/apt/sources.list
vim /etc/apt/sources.list
apt updaate
apt update
vim /etc/apt/sources.list
apt update
apt upgrade
cat /etc/apt/sources.list
apt clean
apt update
apt upgrade
apt-get update
apt upgrade
apt upgrade
vim /etc/apt/sources.list
apt update
apt upgrade
lsb_release -a
apt autoremove
cat /etc/apt/sources.list
vim /etc/apt/sources.list
cat /etc/apt/sources.list
apt update

apt update
apt full-upgrade
lsb_release -a
sudo reboot
exit
exit
lsb_release -a
apt-get install openssh-server
cd etc
cd /etc
cd /ssh
ls -l

cd /ssh
cd ssh
ls -l
cat ssh_config
vim ssh
vim ssh_config
vim sshd_config

vim ssh_config
ssh-keygen
ssh-copy-id root@192.168.0.201
ip -a
ip a
ssh-copy-id root@192.168.1.40
cd ..
cd ..
cd /.ssh
ls -l
cd home
ls -l
cd root
cd /root
ls -l
ls 
cd .ssh
cat known_hosts
ssh-copy-id root@192.168.1.40
cd ..
cd ..
cd /etc
cd ssh
cat ssh
cat ssh_config
vim ssh_config
cd ..
cd ..
ssh-copy-id root@192.168.1.40
cd /etc
cd ssh
cat ssh:config
cat ssh:config
cat ssh_config
vim ssh_config
vim sshd_config
systemctl restaer
systemctl restart
systemctl restart ssh
ssh-copy-id 192.168.1.40
ssh root@192.168.1.40
ssh root@192.168.1.40
apt update 
apt upgrade
apt install apache2 php libapache2-mod-php -y
cd ..
cd ..
cd /home
cd /root
ls -l
cd Material_Adicional_TPVMCA.tar.gz
exit
