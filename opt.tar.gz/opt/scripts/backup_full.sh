mostrar_help() {
	echo "-- Se deben enviar 2 argumentos --"
	echo "1. ORIGEN: Sirve para especificar lo que se va a backupear. "
	echo "2. DESTINO: Sirve para especificar dónde se va a realizar el backup. "
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Opciones:"
	echo "-help - Muestra instrucciones de uso."
	exit 0
}

#0. Valido si se agrega la opción -help o -h y muestro las instrucciones
if [[ "$1" == "-help" ]]; then
 mostrar_help
fi

#1. Valido que recibo 2 argumentos

if [ "$#" -ne 2 ]; then
	echo "Error: Se deben enviar 2 argumentos - ORIGEN y DESTINO"
	echo "Usa el comando '$0 -help' para ver las instrucciones."
	exit 1
fi

#2. Si existen, guardo argumentos en variables
ORIGEN="$1"
DESTINO="$2"

#3. Valido que los sistemas de archivos estén disponibles
if [ ! -d "$ORIGEN" ]; then
	echo "El directorio de origen no está disponible."
	exit 2
fi

if [ ! -d "$DESTINO" ]; then
	echo "El directorio de destino no está disponible."
	exit 2
fi

#4. Seteo variables de configuración para el backup
FECHA_ACTUAL=$(date +%Y%m%d)

#4.1. Obtengo el nombre del directorio de origen
ORIGEN_NOMBRE=$(basename "$ORIGEN")

#4.2. Defino el NOMBRE del archivo del backup COMPRIMIDO
NOMBRE_ARCHIVO_BACKUP="${ORIGEN_NOMBRE}_bkp_${FECHA_ACTUAL}.tar.gz"

#4.3. Defino el DESTINO final para hacer el backup
DESTINO_FINAL_BACKUP="${DESTINO}/${NOMBRE_ARCHIVO_BACKUP}"

#5. Genero el backup
echo " -- Comenzando el backup de $ORIGEN hacia $DESTINO_FINAL_BACKUP -- "

tar -czf "$DESTINO_FINAL_BACKUP" -C "$(dirname "$ORIGEN")" "$ORIGEN_NOMBRE"

#6. Valido si el backup se realizó correctamente y lo notifico
if [ $? -eq 0 ]; then
	echo " -- ¡El backup se realizó correctamente! --"
	echo " -- Backup generado en: $DESTINO_FINAL_BACKUP"
else
	echo " -- Error al generar el backup. -- "
	exit 3
fi

